import TripSteps from "./TripSteps";

function App() {
  return (
    <div>
      <TripSteps />
    </div>
  );
}

export default App;
